package com.comicbonk.app

import com.getcapacitor.*
import com.getcapacitor.annotation.CapacitorPlugin

@CapacitorPlugin(name = "SolanaWallet")
class SolanaWalletPlugin : Plugin() {

    @PluginMethod
    fun connect(call: PluginCall) {
        val ret = JSObject()
        ret.put("success", true)
        ret.put("message", "Android plugin bridge working")
        call.resolve(ret)
    }

    @PluginMethod
    fun isAvailable(call: PluginCall) {
        val ret = JSObject()
        ret.put("available", true)
        call.resolve(ret)
    }
}
