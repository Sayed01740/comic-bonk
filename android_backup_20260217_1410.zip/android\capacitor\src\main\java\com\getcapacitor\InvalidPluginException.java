package com.getcapacitor;

class InvalidPluginException extends Exception {

    public InvalidPluginException(String s) {
        super(s);
    }
}
